Partial Android extraction
Device owner: Bat-Erdene

Notes:
- App data was pulled from a rooted test device.
- Media thumbnails were skipped.
- Some screenshots were copied manually from /sdcard/DCIM/Screenshots.
